package com.utn.tp_spring_grupal.services;

import com.utn.tp_spring_grupal.DTOs.FacturaDetalleDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaDetalleRequestDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaReporteDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaRequestDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaResponseDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaUpdateDTO;
import com.utn.tp_spring_grupal.entities.*;
import com.utn.tp_spring_grupal.repositories.*;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class FacturaService {

    // Reemplazamos EntityManager por el Repositorio
    private final FacturaVentaRepository facturaVentaRepository;
    private final ClienteRepository clienteRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final ListaPrecioArticuloRepository listaPrecioArticuloRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final UsuarioRepository usuarioRepository;

    public FacturaService(FacturaVentaRepository facturaVentaRepository, ClienteRepository clienteRepository, CondicionIvaRepository condicionIvaRepository, ListaPrecioArticuloRepository listaPrecioArticuloRepository, PuntoVentaRepository puntoVentaRepository, TipoMonedaRepository tipoMonedaRepository, UsuarioRepository usuarioRepository) {
        this.facturaVentaRepository = facturaVentaRepository;
        this.clienteRepository = clienteRepository;
        this.condicionIvaRepository = condicionIvaRepository;
        this.listaPrecioArticuloRepository = listaPrecioArticuloRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public FacturaReporteDTO crearFactura(FacturaRequestDTO facturaRequestDTO) {

        Usuario usuarioActual = usuarioRepository.findById(1L)
                .orElseThrow(() -> new NullPointerException("No se encontró el usuario del sistema"));
        TipoMoneda tipoMoneda = tipoMonedaRepository.findById(facturaRequestDTO.getTipoMonedaId())
                .orElseThrow(() -> new NullPointerException("No se encontró tipo de moneda con id " + facturaRequestDTO.getTipoMonedaId()));
        Cliente cliente = clienteRepository.findById(facturaRequestDTO.getClienteId())
                .orElseThrow(() -> new NullPointerException("No se encontró cliente con id " + facturaRequestDTO.getClienteId()));
        CondicionIva condicionIva = condicionIvaRepository.findById(facturaRequestDTO.getCondicionIvaId())
                .orElseThrow(() -> new NullPointerException("No se encontró condición IVA con id " + facturaRequestDTO.getCondicionIvaId()));
        PuntoVenta puntoVenta = puntoVentaRepository.findById(facturaRequestDTO.getPuntoVentaId())
                .orElseThrow(() -> new NullPointerException("No se encontró punto de venta con id " + facturaRequestDTO.getPuntoVentaId()));

        Date ahora = new Date();
        FacturaVenta factura = FacturaVenta.builder()
                .numero(facturaRequestDTO.getNumeroFactura())
                .fechaEmision(facturaRequestDTO.getFechaEmision() != null ? facturaRequestDTO.getFechaEmision() : LocalDate.now())
                .importeCobrado(facturaRequestDTO.getImporteCobrado())
                .observaciones(facturaRequestDTO.getObservaciones())
                .estado(facturaRequestDTO.getEstado())

                // Relaciones
                .cliente(cliente)
                .condicionIva(condicionIva)
                .puntoVenta(puntoVenta)
                .tipoMoneda(tipoMoneda)

                // Auditoría (Heredada de AuditoriaApp)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioActual)
                .usuarioModificacion(usuarioActual)

                // Inicializamos la lista de detalles vacía para llenarla en el siguiente paso
                .detalles(new java.util.ArrayList<>())
                .build();

        double totalFactura = 0.0;
        if (facturaRequestDTO.getDetalles() != null) {
            for (FacturaDetalleRequestDTO dtoDetalle : facturaRequestDTO.getDetalles()) {

                ListaPrecioArticulo listaPrecioArticulo = listaPrecioArticuloRepository.findByArticuloId(dtoDetalle.getArticuloId())
                        .orElseThrow(() -> new NullPointerException("No se encontró lista de precios para el artículo id " + dtoDetalle.getArticuloId()));

                double precioUnitario = listaPrecioArticulo.getPrecioVenta();
                double cantidad = dtoDetalle.getCantidad();
                double bonificacion = dtoDetalle.getPorcentajeBonificacion();

                // A) Cálculo del Importe Neto (Precio * Cantidad aplicado el descuento)
                double importeNeto = (precioUnitario * cantidad) * (1 - (bonificacion / 100.0));
                // B) Cálculo del IVA (Asumiendo 21% estándar)
                double importeIva = importeNeto * 0.21;
                // C) Cálculo del Subtotal de la línea
                double importeSubtotal = importeNeto + importeIva;
                // D) Sumar al total de la factura
                totalFactura += importeSubtotal;

                // Construir el detalle con los valores calculados
                FacturaVentaDetalle detalle = FacturaVentaDetalle.builder()
                        .descripcion(dtoDetalle.getDescripcion())
                        .cantidad(cantidad)
                        .precioUnitario(precioUnitario)
                        .porcentajeBonificacion(bonificacion)
                        .importeNeto(importeNeto)
                        .importeIva(importeIva)
                        .importeSubtotal(importeSubtotal)
                        .listaPrecioArticulo(listaPrecioArticulo)
                        .factura(factura) // Asociamos el detalle con la factura creada arriba
                        .build();
                factura.getDetalles().add(detalle);
            }
        }
        factura.setImporteTotal(totalFactura);
        factura.setImporteSaldo(totalFactura - factura.getImporteCobrado());
        factura = facturaVentaRepository.save(factura);

        // RETORNAR RESULTADO
        return new FacturaReporteDTO(
                factura.getId(),
                factura.getNumero(),
                factura.getFechaEmision(),
                factura.getImporteTotal(),
                cliente.getDenominacion(),
                condicionIva.getDenominacion(),
                puntoVenta.getDescripcion(),
                factura.getDetalles().size(),
                factura.getEstado()
        );
    }

    // Actualización
    public FacturaReporteDTO actualizarFactura(Long id, FacturaUpdateDTO facturaUpdateDTO) {
        FacturaVenta factura = facturaVentaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recurso no encontrado: No existe la factura con ID " + id));

        if (facturaUpdateDTO.getTipoMonedaId() != null) {
            TipoMoneda tipoMoneda = tipoMonedaRepository.findById(facturaUpdateDTO.getTipoMonedaId())
                    .orElseThrow(() -> new RuntimeException("No se encontró tipo de moneda"));
            factura.setTipoMoneda(tipoMoneda);
        }
        if (facturaUpdateDTO.getClienteId() != null) {
            Cliente cliente = clienteRepository.findById(facturaUpdateDTO.getClienteId())
                    .orElseThrow(() -> new RuntimeException("No se encontró cliente"));
            factura.setCliente(cliente);
        }
        if (facturaUpdateDTO.getCondicionIvaId() != null) {
            CondicionIva condicionIva = condicionIvaRepository.findById(facturaUpdateDTO.getCondicionIvaId())
                    .orElseThrow(() -> new RuntimeException("No se encontró condición IVA"));
            factura.setCondicionIva(condicionIva);
        }
        if (facturaUpdateDTO.getPuntoVentaId() != null) {
            PuntoVenta puntoVenta = puntoVentaRepository.findById(facturaUpdateDTO.getPuntoVentaId())
                    .orElseThrow(() -> new RuntimeException("No se encontró punto de venta"));
            factura.setPuntoVenta(puntoVenta);
        }

        // 2. Actualizar cabecera SOLO si los campos no son nulos
        if (facturaUpdateDTO.getFechaEmision() != null) {
            factura.setFechaEmision(facturaUpdateDTO.getFechaEmision());
        }
        if (facturaUpdateDTO.getObservaciones() != null) {
            factura.setObservaciones(facturaUpdateDTO.getObservaciones());
        }
        if (facturaUpdateDTO.getEstado() != null) {
            factura.setEstado(facturaUpdateDTO.getEstado());
            if ("ANULADA".equals(facturaUpdateDTO.getEstado())) {
                factura.setFechaAnulacion(new Date());
            }
        }

        if (facturaUpdateDTO.getImporteCobrado() != null) {
            factura.setImporteCobrado(facturaUpdateDTO.getImporteCobrado());
        }

        factura.setFechaModificacion(new Date());

        // 3. Actualizar ítems SOLO si el arreglo de detalles no es nulo
        if (facturaUpdateDTO.getDetalles() != null) {
            factura.getDetalles().clear();
            double totalFactura = 0.0;

            for (FacturaDetalleRequestDTO dtoDetalle : facturaUpdateDTO.getDetalles()) {
                ListaPrecioArticulo listaPrecioArticulo = listaPrecioArticuloRepository.findByArticuloId(dtoDetalle.getArticuloId())
                        .orElseThrow(() -> new RuntimeException("No se encontró lista de precios para el artículo id " + dtoDetalle.getArticuloId()));

                double precioUnitario = listaPrecioArticulo.getPrecioVenta();
                double cantidad = dtoDetalle.getCantidad();
                double bonificacion = dtoDetalle.getPorcentajeBonificacion();

                // Recálculo de importes
                double importeNeto = (precioUnitario * cantidad) * (1 - (bonificacion / 100.0));
                double importeIva = importeNeto * 0.21;
                double importeSubtotal = importeNeto + importeIva;

                totalFactura += importeSubtotal;

                FacturaVentaDetalle detalle = FacturaVentaDetalle.builder()
                        .descripcion(dtoDetalle.getDescripcion())
                        .cantidad(cantidad)
                        .precioUnitario(precioUnitario)
                        .porcentajeBonificacion(bonificacion)
                        .importeNeto(importeNeto)
                        .importeIva(importeIva)
                        .importeSubtotal(importeSubtotal)
                        .listaPrecioArticulo(listaPrecioArticulo)
                        .factura(factura)
                        .build();

                factura.getDetalles().add(detalle);
            }

            // Reasignar los totales porque se modificaron los detalles
            factura.setImporteTotal(totalFactura);
            factura.setImporteSaldo(totalFactura - factura.getImporteCobrado());
        } else {
            // Si NO se enviaron detalles nuevos pero el importe cobrado cambió,
            // recalculamos el saldo en base al importe total que ya tenía la factura.
            factura.setImporteSaldo(factura.getImporteTotal() - factura.getImporteCobrado());
        }

        facturaVentaRepository.save(factura);


        return new FacturaReporteDTO(
                factura.getId(),
                factura.getNumero(),
                factura.getFechaEmision(),
                factura.getImporteTotal(),
                factura.getCliente() != null ? factura.getCliente().getDenominacion() : "Consumidor Final",
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getDetalles().size(),
                factura.getEstado()
        );
    }

    // Eliminación lógica (anulación): la factura sigue registrada con estado ANULADA.
    public void anularFactura(Long id) {
        FacturaVenta factura = facturaVentaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recurso no encontrado: No existe la factura con ID " + id));

        // Aplicamos la baja lógica como requiere un sistema de facturación
        factura.setEstado("ANULADA");
        factura.setFechaAnulacion(new Date());
        factura.setFechaModificacion(new Date());

        facturaVentaRepository.save(factura);
    }

    public List<FacturaReporteDTO> buscarFacturasFiltradas(LocalDate fechaDesde, LocalDate fechaHasta, String estado, Double montoMinimo) {
        return facturaVentaRepository.buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo);
    }

    // Detalle completo para precargar la edición (cabecera + renglones).
    public FacturaResponseDTO obtenerFactura(Long id) {
        FacturaVenta factura = facturaVentaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recurso no encontrado: No existe la factura con ID " + id));
        List<FacturaDetalleDTO> detalles = factura.getDetalles().stream()
                .map(d -> new FacturaDetalleDTO(
                        d.getListaPrecioArticulo().getArticulo().getId(),
                        d.getDescripcion(),
                        d.getCantidad(),
                        d.getPorcentajeBonificacion(),
                        d.getListaPrecioArticulo().getPrecioVenta()))
                .toList();
        return new FacturaResponseDTO(
                factura.getId(),
                factura.getNumero(),
                factura.getEstado(),
                factura.getFechaEmision(),
                factura.getObservaciones(),
                factura.getImporteCobrado(),
                factura.getImporteTotal(),
                factura.getImporteSaldo(),
                factura.getCliente() != null ? factura.getCliente().getId() : null,
                factura.getCondicionIva().getId(),
                factura.getPuntoVenta().getId(),
                factura.getTipoMoneda().getId(),
                detalles);
    }

    // Genera el archivo PDF en memoria y retorna los bytes
    public byte[] generarReportePDF(List<FacturaReporteDTO> datos) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PdfWriter writer = new PdfWriter(baos);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            document.add(new Paragraph("Reporte Ejecutivo de Ventas").setBold().setFontSize(16));
            document.add(new Paragraph(" ")); // Espacio

            // Crear tabla con 7 columnas
            Table table = new Table(new float[] { 1, 2, 3, 2, 2, 2, 1 });
            table.useAllAvailableWidth();

            // Encabezados
            String[] encabezados = { "Número", "Fecha", "Cliente", "Cond. IVA", "Pto. Venta", "Total", "Items" };
            for (String header : encabezados) {
                table.addHeaderCell(new Cell().add(new Paragraph(header).setBold()));
            }

            DateTimeFormatter sdf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            // Llenar datos
            for (FacturaReporteDTO dto : datos) {
                table.addCell(String.valueOf(dto.getNumeroFactura()));
                table.addCell(dto.getFechaEmision() != null ? sdf.format(dto.getFechaEmision()) : "");
                table.addCell(dto.getClienteDenominacion());
                table.addCell(dto.getCondicionIva());
                table.addCell(dto.getPuntoVentaDescripcion());
                table.addCell(String.format("$%.2f", dto.getImporteTotal()));
                table.addCell(String.valueOf(dto.getCantidadItems()));
            }

            document.add(table);
            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Genera un archivo TXT en memoria separado por tabulaciones y retorna los bytes
    public byte[] generarReporteExcelTxt(List<FacturaReporteDTO> datos) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintWriter pw = new PrintWriter(baos);
            DateTimeFormatter sdf = DateTimeFormatter.ofPattern("dd/MM/yyyy");

            // Escribir encabezados separados por tabulación (\t)
            pw.println("Número\tFecha de Emisión\tCliente\tCondición IVA\tPunto de Venta\tImporte Total\tCantidad de Ítems");

            // Escribir filas
            for (FacturaReporteDTO dto : datos) {
                String fecha = dto.getFechaEmision() != null ? sdf.format(dto.getFechaEmision()) : "";
                pw.printf("%d\t%s\t%s\t%s\t%s\t%.2f\t%d%n",
                        dto.getNumeroFactura(),
                        fecha,
                        dto.getClienteDenominacion(),
                        dto.getCondicionIva(),
                        dto.getPuntoVentaDescripcion(),
                        dto.getImporteTotal(),
                        dto.getCantidadItems());
            }
            pw.flush();
            return baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}