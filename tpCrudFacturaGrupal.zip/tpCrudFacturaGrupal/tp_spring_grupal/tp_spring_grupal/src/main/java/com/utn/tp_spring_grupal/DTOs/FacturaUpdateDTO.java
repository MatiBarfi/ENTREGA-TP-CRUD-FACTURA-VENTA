package com.utn.tp_spring_grupal.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

/**
 * Actualización parcial de una factura (PUT /api/facturas/{id}).
 * Todos los campos son opcionales: el service solo aplica los que llegan con valor.
 * Es el espejo de FacturaUpdateDTO del frontend.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FacturaUpdateDTO {
    private String estado;
    private LocalDate fechaEmision;
    private String observaciones;
    private Double importeCobrado;
    private Long clienteId;
    private Long condicionIvaId;
    private Long puntoVentaId;
    private Long tipoMonedaId;
    private List<FacturaDetalleRequestDTO> detalles;
}
