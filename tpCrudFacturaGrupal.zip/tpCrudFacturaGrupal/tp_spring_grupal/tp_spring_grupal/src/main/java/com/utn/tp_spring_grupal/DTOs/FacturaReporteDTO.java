package com.utn.tp_spring_grupal.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FacturaReporteDTO {
    private Long id;
    private Long numeroFactura;
    private LocalDate fechaEmision;
    private double importeTotal;
    private String clienteDenominacion;
    private String condicionIva;
    private String puntoVentaDescripcion;
    private long cantidadItems;
    private String estado;
}
