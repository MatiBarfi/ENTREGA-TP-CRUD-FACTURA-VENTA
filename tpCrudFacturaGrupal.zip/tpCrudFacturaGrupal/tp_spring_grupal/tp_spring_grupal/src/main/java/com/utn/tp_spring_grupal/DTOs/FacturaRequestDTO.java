package com.utn.tp_spring_grupal.DTOs;


import com.utn.tp_spring_grupal.entities.FacturaVenta;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FacturaRequestDTO {
    private Long numeroFactura;
    private LocalDate fechaEmision;
    private Double importeCobrado;
    private Double importeSaldo;
    private Double importeTotal;
    private String observaciones;
    private String estado;
    private Long clienteId;
    private Long condicionIvaId;
    private Long puntoVentaId;
    private Long tipoMonedaId;
    private List<FacturaDetalleRequestDTO> detalles;

}
