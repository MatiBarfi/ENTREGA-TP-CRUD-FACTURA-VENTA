package com.utn.tp_spring_grupal.DTOs;

/**
 * DTOs chicos de solo lectura para poblar los selects del frontend.
 * Se usan records para no exponer entidades (evita serialización lazy).
 */
public final class CatalogoDTOs {

    private CatalogoDTOs() {
    }

    public record ClienteDTO(Long id, String denominacion, String cuitCuil) {
    }

    public record CondicionIvaDTO(Long id, String denominacion) {
    }

    public record PuntoVentaDTO(Long id, String descripcion) {
    }

    public record TipoMonedaDTO(Long id, String denominacion, String simbolo) {
    }

    public record ArticuloDTO(Long id, String codigo, String denominacion, double precioVenta) {
    }
}
