package com.utn.tp_spring_grupal.services;

import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.ArticuloDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.ClienteDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.CondicionIvaDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.PuntoVentaDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.TipoMonedaDTO;
import com.utn.tp_spring_grupal.repositories.ArticuloRepository;
import com.utn.tp_spring_grupal.repositories.ClienteRepository;
import com.utn.tp_spring_grupal.repositories.CondicionIvaRepository;
import com.utn.tp_spring_grupal.repositories.ListaPrecioArticuloRepository;
import com.utn.tp_spring_grupal.repositories.PuntoVentaRepository;
import com.utn.tp_spring_grupal.repositories.TipoMonedaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class CatalogoService {

    private final ClienteRepository clienteRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final ArticuloRepository articuloRepository;
    private final ListaPrecioArticuloRepository listaPrecioArticuloRepository;

    public CatalogoService(ClienteRepository clienteRepository,
                           CondicionIvaRepository condicionIvaRepository,
                           PuntoVentaRepository puntoVentaRepository,
                           TipoMonedaRepository tipoMonedaRepository,
                           ArticuloRepository articuloRepository,
                           ListaPrecioArticuloRepository listaPrecioArticuloRepository) {
        this.clienteRepository = clienteRepository;
        this.condicionIvaRepository = condicionIvaRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.articuloRepository = articuloRepository;
        this.listaPrecioArticuloRepository = listaPrecioArticuloRepository;
    }

    public List<ClienteDTO> listarClientes() {
        return clienteRepository.findAll().stream()
                .map(c -> new ClienteDTO(c.getId(), c.getDenominacion(), c.getCuitCuil()))
                .toList();
    }

    public List<CondicionIvaDTO> listarCondicionesIva() {
        return condicionIvaRepository.findAll().stream()
                .map(c -> new CondicionIvaDTO(c.getId(), c.getDenominacion()))
                .toList();
    }

    public List<PuntoVentaDTO> listarPuntosVenta() {
        return puntoVentaRepository.findAll().stream()
                .map(p -> new PuntoVentaDTO(p.getId(), p.getDescripcion()))
                .toList();
    }

    public List<TipoMonedaDTO> listarTiposMoneda() {
        return tipoMonedaRepository.findAll().stream()
                .map(t -> new TipoMonedaDTO(t.getId(), t.getDenominacion(), t.getSimbolo()))
                .toList();
    }

    public List<ArticuloDTO> listarArticulos() {
        return articuloRepository.findAll().stream()
                .map(a -> new ArticuloDTO(
                        a.getId(),
                        a.getCodigo(),
                        a.getDenominacion(),
                        listaPrecioArticuloRepository.findByArticuloId(a.getId())
                                .map(lp -> lp.getPrecioVenta())
                                .orElse(0.0)))
                .toList();
    }
}
