package com.utn.tp_spring_grupal.DTOs;

import java.time.LocalDate;
import java.util.List;

/** Factura completa (cabecera + renglones) para precargar el formulario de edición. */
public record FacturaResponseDTO(
        Long id,
        Long numeroFactura,
        String estado,
        LocalDate fechaEmision,
        String observaciones,
        Double importeCobrado,
        Double importeTotal,
        Double importeSaldo,
        Long clienteId,
        Long condicionIvaId,
        Long puntoVentaId,
        Long tipoMonedaId,
        List<FacturaDetalleDTO> detalles) {
}
