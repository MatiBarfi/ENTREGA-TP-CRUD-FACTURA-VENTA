package com.utn.tp_spring_grupal.controllers;

import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.ArticuloDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.ClienteDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.CondicionIvaDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.PuntoVentaDTO;
import com.utn.tp_spring_grupal.DTOs.CatalogoDTOs.TipoMonedaDTO;
import com.utn.tp_spring_grupal.services.CatalogoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CatalogoController {

    private final CatalogoService catalogoService;

    public CatalogoController(CatalogoService catalogoService) {
        this.catalogoService = catalogoService;
    }

    @GetMapping("/clientes")
    public ResponseEntity<List<ClienteDTO>> listarClientes() {
        return ResponseEntity.ok(catalogoService.listarClientes());
    }

    @GetMapping("/condiciones-iva")
    public ResponseEntity<List<CondicionIvaDTO>> listarCondicionesIva() {
        return ResponseEntity.ok(catalogoService.listarCondicionesIva());
    }

    @GetMapping("/puntos-venta")
    public ResponseEntity<List<PuntoVentaDTO>> listarPuntosVenta() {
        return ResponseEntity.ok(catalogoService.listarPuntosVenta());
    }

    @GetMapping("/tipos-moneda")
    public ResponseEntity<List<TipoMonedaDTO>> listarTiposMoneda() {
        return ResponseEntity.ok(catalogoService.listarTiposMoneda());
    }

    @GetMapping("/articulos")
    public ResponseEntity<List<ArticuloDTO>> listarArticulos() {
        return ResponseEntity.ok(catalogoService.listarArticulos());
    }
}
