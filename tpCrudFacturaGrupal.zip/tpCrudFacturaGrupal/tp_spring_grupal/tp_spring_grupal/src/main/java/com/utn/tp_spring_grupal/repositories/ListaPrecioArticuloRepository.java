package com.utn.tp_spring_grupal.repositories;

import com.utn.tp_spring_grupal.entities.ListaPrecioArticulo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ListaPrecioArticuloRepository extends JpaRepository<ListaPrecioArticulo, Long> {
    // Spring Data JPA lee "findBy" + "Articulo" + "Id" y genera la consulta SQL por vos.
    Optional<ListaPrecioArticulo> findByArticuloId(Long articuloId);
}
