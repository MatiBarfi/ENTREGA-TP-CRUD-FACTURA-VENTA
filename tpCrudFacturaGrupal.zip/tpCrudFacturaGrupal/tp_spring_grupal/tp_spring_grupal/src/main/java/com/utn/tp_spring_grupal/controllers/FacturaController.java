package com.utn.tp_spring_grupal.controllers;

import com.utn.tp_spring_grupal.DTOs.FacturaReporteDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaRequestDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaResponseDTO;
import com.utn.tp_spring_grupal.DTOs.FacturaUpdateDTO;
import com.utn.tp_spring_grupal.services.FacturaService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/facturas")
public class FacturaController {

    private final FacturaService facturaService;

    public FacturaController(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    // POST: Crear Factura
    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crearFactura(@RequestBody FacturaRequestDTO facturaRequestDTO) {
        FacturaReporteDTO reporteGenerado = facturaService.crearFactura(facturaRequestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(reporteGenerado);
    }

    // PUT: Actualizar Factura
    @PutMapping("/{id}")
    public ResponseEntity<FacturaReporteDTO> actualizarFactura(
            @PathVariable Long id,
            @RequestBody FacturaUpdateDTO facturaUpdateDTO) {
        FacturaReporteDTO reporteActualizado = facturaService.actualizarFactura(id, facturaUpdateDTO);
        return ResponseEntity.ok(reporteActualizado);
    }


    // DELETE: baja LÓGICA (anulación) de la factura. La factura sigue registrada con estado ANULADA.
    // Para cambiar el estado u otros campos usar PUT /{id} con actualización parcial.
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> anularFactura(@PathVariable Long id) {
        facturaService.anularFactura(id);
        return ResponseEntity.noContent().build();
    }

    // GET /{id}: detalle completo (cabecera + renglones) para precargar la edición.
    @GetMapping("/{id}")
    public ResponseEntity<FacturaResponseDTO> obtenerFactura(@PathVariable Long id) {
        return ResponseEntity.ok(facturaService.obtenerFactura(id));
    }

    @GetMapping
    public ResponseEntity<List<FacturaReporteDTO>> buscarFacturasFiltradas(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) {
        // "hasta" es inclusivo: se compara con < día siguiente a las 00:00.
        // LocalDate es fecha pura (sin hora ni zona), igual que la columna DATE.
        LocalDate hasta = fechaHasta != null ? fechaHasta.plusDays(1) : null;
        return ResponseEntity.ok(facturaService.buscarFacturasFiltradas(fechaDesde, hasta, estado, montoMinimo));
    }

    @GetMapping("/generar-pdf")
    public ResponseEntity<byte[]> probarGeneracionPdf() {
        List<FacturaReporteDTO> datos = facturaService.buscarFacturasFiltradas(null, null, null, null);
        byte[] pdfBytes = facturaService.generarReportePDF(datos);

        HttpHeaders headers = new HttpHeaders();
        // Le indicamos al navegador que es un PDF y que debe descargarlo como archivo
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", "reporte_ventas.pdf");

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes);
    }

    @GetMapping("/generar-excel")
    public ResponseEntity<byte[]> probarGeneracionExcel() {
        List<FacturaReporteDTO> datos = facturaService.buscarFacturasFiltradas(null, null, null, null);
        byte[] txtBytes = facturaService.generarReporteExcelTxt(datos);

        HttpHeaders headers = new HttpHeaders();
        // Usamos MediaType.TEXT_PLAIN ya que es un txt con formato tabular
        headers.setContentType(MediaType.TEXT_PLAIN);
        headers.setContentDispositionFormData("attachment", "reporte_ventas.txt");

        return ResponseEntity.ok()
                .headers(headers)
                .body(txtBytes);
    }
}