package com.utn.tp_spring_grupal;

import com.utn.tp_spring_grupal.entities.*;
import jakarta.persistence.EntityManager;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

@Component
public class DataLoader implements CommandLineRunner {

    private final EntityManager em;

    public DataLoader(EntityManager em) {
        this.em = em;
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        // Verificar si ya existen facturas para no duplicar datos en cada reinicio
        Long count = em.createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class).getSingleResult();
        if (count > 0) {
            System.out.println("La base de datos ya contiene información. Omitiendo carga inicial.");
            return;
        }

        Date ahora = new Date();
        // fechaEmision es una fecha pura (LocalDate): sin hora ni zona horaria.
        LocalDate hoy = LocalDate.now();
        System.out.println("Inyectando datos de prueba para Reportes y API REST...");

        // 1. Crear Usuario base (Requerido por AuditoriaApp)
        Usuario usuarioAdmin = Usuario.builder()
                .usuario("admin")
                .clave("123456")
                .nombre("Juan")
                .apellido("Perez")
                .build();
        em.persist(usuarioAdmin);

        PuntoVenta puntoVenta = PuntoVenta.builder()
                .numero(1)
                .descripcion("Punto de Venta Centro")
                .tipoEmision("Factura Electrónica")
                .domicilioComercial("Av. San Martín 1000")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(puntoVenta);

        PuntoVenta puntoVentaNorte = PuntoVenta.builder()
                .numero(2)
                .descripcion("Punto de Venta Norte")
                .tipoEmision("Factura Electrónica")
                .domicilioComercial("Av. Colón 2500")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(puntoVentaNorte);

        PuntoVenta puntoVentaDeposito = PuntoVenta.builder()
                .numero(3)
                .descripcion("Depósito Central")
                .tipoEmision("Factura Manual")
                .domicilioComercial("Ruta 9 Km 12")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(puntoVentaDeposito);

        // 2. RUBRO
        Rubro rubroElec = new Rubro();
        rubroElec.setCodigo(10);
        rubroElec.setDenominacion("Electrónica");
        rubroElec.setFechaAlta(ahora);
        rubroElec.setFechaModificacion(ahora);
        rubroElec.setUsuarioCarga(usuarioAdmin);
        rubroElec.setUsuarioModificacion(usuarioAdmin);
        em.persist(rubroElec);

        // 3. CLIENTE (Contacto, Domicilio, Cliente)
        Contacto contacto = new Contacto();
        contacto.setEmail("juanperez@mail.com");
        em.persist(contacto);

        Domicilio domicilio = Domicilio.builder()
                .nombreCalle("Belgrano")
                .numeroCalle("456")
                .build();
        em.persist(domicilio);

        Cliente cliente = Cliente.builder()
                .cuitCuil("20-28123456-7")
                .denominacion("Juan Perez")
                .contacto(contacto)
                .domicilio(domicilio)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(cliente);

        // 4. MARCAS Y ARTÍCULOS
        Marca marcaLogi = Marca.builder()
                .codigo(101)
                .denominacion("Logitech")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(marcaLogi);

        Marca marcaSam = Marca.builder()
                .codigo(102)
                .denominacion("Samsung")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(marcaSam);

        Articulo artMouse = Articulo.builder()
                .codigo("ART-001")
                .denominacion("Mouse Inalámbrico")
                .marca(marcaLogi)
                .rubro(rubroElec) // Asignamos el rubro
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(artMouse);

        Articulo artMonitor = Articulo.builder()
                .codigo("ART-002")
                .denominacion("Monitor 24 Pulgadas")
                .marca(marcaSam)
                .rubro(rubroElec)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(artMonitor); // Este artículo NO se facturará

        // 5. LISTAS DE PRECIO
        ListaPrecio listaPrecio = ListaPrecio.builder()
                .codigo("LP-MAY")
                .denominacion("Lista Mayorista")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(listaPrecio);

        ListaPrecioArticulo precioMouse = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio)
                .articulo(artMouse)
                .precioVenta(15000.0)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(precioMouse);

        ListaPrecioArticulo precioMonitor = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio)
                .articulo(artMonitor)
                .precioVenta(150000.0)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(precioMonitor);

        // 5.5 CONDICIONES IVA
        CondicionIva condicionIva = CondicionIva.builder()
                .codigoAfip(1)
                .denominacion("IVA Responsable Inscripto")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(condicionIva);

        CondicionIva monotributo = CondicionIva.builder()
                .codigoAfip(6)
                .denominacion("Responsable Monotributo")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(monotributo);

        CondicionIva exento = CondicionIva.builder()
                .codigoAfip(4)
                .denominacion("IVA Sujeto Exento")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(exento);

        // 5.6 TIPO MONEDA
        TipoMoneda tipoMonedaPesos = TipoMoneda.builder()
                .codigoAfip("PES")
                .denominacion("Pesos Argentinos")
                .simbolo("$")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(tipoMonedaPesos);

        TipoMoneda tipoMonedaDolar = TipoMoneda.builder()
                .codigoAfip("DOL")
                .denominacion("Dólar Estadounidense")
                .simbolo("US$")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(tipoMonedaDolar);

        TipoMoneda tipoMonedaEuro = TipoMoneda.builder()
                .codigoAfip("EUR")
                .denominacion("Euro")
                .simbolo("€")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(tipoMonedaEuro);

        // 6. FACTURAS Y DETALLES
        // Factura 1: $30,000 (Medio Valor)
        FacturaVenta factura1 = FacturaVenta.builder()
                .numero(1001L)
                .fechaEmision(hoy)
                .puntoVenta(puntoVenta)
                .condicionIva(condicionIva)
                .cliente(cliente)
                .tipoMoneda(tipoMonedaPesos)
                .importeCobrado(30000.0)
                .importeSaldo(0.0)
                .importeTotal(30000.0)
                .cae("73428917238912")
                .resultadoAfip("A")
                .estado("Emitida")
                .observaciones("Venta minorista")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .detalles(new ArrayList<>())
                .build();

        FacturaVentaDetalle det1F1 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Unidad 1")
                .cantidad(1.0)
                .precioUnitario(15000.0)
                .importeSubtotal(15000.0)
                .factura(factura1)
                .build();

        FacturaVentaDetalle det2F1 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Unidad 2")
                .cantidad(1.0)
                .precioUnitario(15000.0)
                .importeSubtotal(15000.0)
                .factura(factura1)
                .build();

        factura1.getDetalles().add(det1F1);
        factura1.getDetalles().add(det2F1);

        em.persist(factura1);

        // Factura 2 (Pendiente: cobrada en forma parcial)
        FacturaVenta factura2 = FacturaVenta.builder()
                .numero(1002L)
                .fechaEmision(hoy)
                .puntoVenta(puntoVenta)
                .condicionIva(condicionIva)
                .cliente(cliente)
                .tipoMoneda(tipoMonedaPesos)
                .importeCobrado(50000.0)
                .importeSaldo(40000.0)
                .importeTotal(90000.0)
                .cae("99887766554433")
                .resultadoAfip("A")
                .estado("Pendiente")
                .observaciones("Venta mayorista")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .detalles(new ArrayList<>())
                .build();

        FacturaVentaDetalle det1F2 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Lote Mayorista")
                .cantidad(6.0)
                .precioUnitario(15000.0)
                .importeSubtotal(90000.0)
                .factura(factura2)
                .build();

        factura2.getDetalles().add(det1F2);

        em.persist(factura2);

        // Factura 3: ANULADA de hace 40 días (para probar filtros por fecha y estado)
        Date hace40Dias = new Date(ahora.getTime() - 40L * 24 * 60 * 60 * 1000);
        FacturaVenta factura3 = FacturaVenta.builder()
                .numero(1003L)
                .fechaEmision(hoy.minusDays(40))
                .puntoVenta(puntoVentaNorte)
                .condicionIva(monotributo)
                .cliente(cliente)
                .tipoMoneda(tipoMonedaDolar)
                .importeCobrado(0.0)
                .importeSaldo(150000.0)
                .importeTotal(150000.0)
                .cae("11223344556677")
                .resultadoAfip("A")
                .estado("ANULADA")
                .fechaAnulacion(ahora)
                .observaciones("Venta anulada a pedido del cliente")
                .fechaAlta(hace40Dias)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .detalles(new ArrayList<>())
                .build();

        FacturaVentaDetalle det1F3 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMonitor)
                .descripcion("Monitor 24 Pulgadas")
                .cantidad(1.0)
                .precioUnitario(150000.0)
                .importeSubtotal(150000.0)
                .factura(factura3)
                .build();

        factura3.getDetalles().add(det1F3);

        em.persist(factura3);

        // Factura 4: PAGADA de hoy (para probar el filtro por estado)
        FacturaVenta factura4 = FacturaVenta.builder()
                .numero(1004L)
                .fechaEmision(hoy)
                .puntoVenta(puntoVentaDeposito)
                .condicionIva(exento)
                .cliente(cliente)
                .tipoMoneda(tipoMonedaPesos)
                .importeCobrado(30000.0)
                .importeSaldo(0.0)
                .importeTotal(30000.0)
                .cae("44556677889900")
                .resultadoAfip("A")
                .estado("Pagada")
                .observaciones("Venta cobrada en el acto")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .detalles(new ArrayList<>())
                .build();

        FacturaVentaDetalle det1F4 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Unidad 1")
                .cantidad(1.0)
                .precioUnitario(15000.0)
                .importeSubtotal(15000.0)
                .factura(factura4)
                .build();

        FacturaVentaDetalle det2F4 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Unidad 2")
                .cantidad(1.0)
                .precioUnitario(15000.0)
                .importeSubtotal(15000.0)
                .factura(factura4)
                .build();

        factura4.getDetalles().add(det1F4);
        factura4.getDetalles().add(det2F4);

        em.persist(factura4);

        System.out.println(" Datos de prueba cargados con éxito!");
    }
}