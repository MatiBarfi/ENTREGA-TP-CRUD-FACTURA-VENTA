package com.utn.tp_spring_grupal.DTOs;

/**
 * Renglón de una factura para lectura (detalle completo para edición).
 * El precio es informativo: al guardar, el backend lo recalcula desde la lista de precios.
 */
public record FacturaDetalleDTO(
        Long articuloId,
        String descripcion,
        double cantidad,
        double porcentajeBonificacion,
        double precioVenta) {
}
