package com.utn.tp_spring_grupal.DTOs;


import com.utn.tp_spring_grupal.entities.FacturaVenta;
import com.utn.tp_spring_grupal.entities.FacturaVentaDetalle;
import com.utn.tp_spring_grupal.entities.ListaPrecioArticulo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FacturaDetalleRequestDTO {
    private String descripcion;
    private double cantidad;
    private double porcentajeBonificacion;
    private Long articuloId;
}
