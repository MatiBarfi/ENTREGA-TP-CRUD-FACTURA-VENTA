package com.utn.tp_spring_grupal.repositories;

import com.utn.tp_spring_grupal.DTOs.FacturaReporteDTO;
import com.utn.tp_spring_grupal.entities.FacturaVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface FacturaVentaRepository extends JpaRepository<FacturaVenta, Long> {
    @Query("SELECT new com.utn.tp_spring_grupal.DTOs.FacturaReporteDTO(" +
            " f.id, f.numero, f.fechaEmision, f.importeTotal, COALESCE(c.denominacion, 'Consumidor Final'), " +
            " ci.denominacion, pv.descripcion, COUNT(d), f.estado" +
            ") " +
            "FROM FacturaVenta f " +
            "LEFT JOIN f.cliente c " +
            "JOIN f.condicionIva ci " +
            "JOIN f.puntoVenta pv " +
            "JOIN f.detalles d " +
            "WHERE (CAST(:fechaDesde AS date) IS NULL OR f.fechaEmision >= :fechaDesde) " +
            "AND (CAST(:fechaHasta AS date) IS NULL OR f.fechaEmision < :fechaHasta) " +
            "AND (CAST(:estado AS string) IS NULL OR f.estado = :estado) " +
            "AND (CAST(:montoMinimo AS double) IS NULL OR f.importeTotal >= :montoMinimo) " +
            "GROUP BY f.id, f.numero, f.fechaEmision, f.importeTotal, f.estado, c.denominacion, ci.denominacion, pv.descripcion")
    List<FacturaReporteDTO> buscarFacturasFiltradas(
            @Param("fechaDesde") LocalDate fechaDesde,
            @Param("fechaHasta") LocalDate fechaHasta,
            @Param("estado") String estado,
            @Param("montoMinimo") Double montoMinimo);
}
