export const API_BASE_URL = 'http://localhost:8080/api';

export const RUTAS = {
  facturas: `${API_BASE_URL}/facturas`,
  clientes: `${API_BASE_URL}/clientes`,
  condicionesIva: `${API_BASE_URL}/condiciones-iva`,
  puntosVenta: `${API_BASE_URL}/puntos-venta`,
  tiposMoneda: `${API_BASE_URL}/tipos-moneda`,
  articulos: `${API_BASE_URL}/articulos`,
} as const;
