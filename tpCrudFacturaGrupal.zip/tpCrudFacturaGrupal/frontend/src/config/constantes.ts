// Valores exactos que espera el backend (comparación case-sensitive).
export const ESTADO_EMITIDA = 'Emitida' as const;
export const ESTADO_ANULADA = 'ANULADA' as const;
export const ESTADO_PAGADA = 'Pagada' as const;
export const ESTADO_PENDIENTE = 'Pendiente' as const;

export type EstadoFactura =
  | typeof ESTADO_EMITIDA
  | typeof ESTADO_ANULADA
  | typeof ESTADO_PAGADA
  | typeof ESTADO_PENDIENTE;

// Alícuota estándar que usa el backend para recalcular cada renglón.
export const IVA_PORCENTAJE = 0.21;

export const TOAST_MS = 4500;
