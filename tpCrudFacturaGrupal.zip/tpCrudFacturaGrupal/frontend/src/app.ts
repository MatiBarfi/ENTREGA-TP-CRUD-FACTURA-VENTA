import type { FacturaFiltrosDTO, FacturaReporteDTO } from './models/factura.dto';
import { obtenerCatalogos, type Catalogos } from './services/CatalogoService';
import { FacturaService } from './services/FacturaService';
import { mensajeDeError } from './services/httpClient';
import { qs } from './utils/dom';
import { confirmar } from './ui/confirmDialog';
import { editarFactura } from './ui/editarModal';
import { pedirEstado } from './ui/estadoModal';
import { initFacturaModal } from './ui/facturaModal';
import { initTablaFacturas, type AccionFila } from './ui/facturasTable';
import { initFiltrosForm } from './ui/filtrosForm';
import { initToasts, mostrarToast } from './ui/toast';

const servicio = new FacturaService();

/** Orquestador: conecta filtros, tabla, modal y servicios. Sin estado global. */
export async function iniciarApp(): Promise<void> {
  initToasts();
  const tabla = initTablaFacturas({ alAccionar: (accion, factura) => void onAccion(accion, factura) });

  let catalogos: Catalogos;
  try {
    catalogos = await obtenerCatalogos();
  } catch (error: unknown) {
    mostrarFatal(mensajeDeError(error));
    return;
  }

  let filtros: FacturaFiltrosDTO = {};
  let facturas: FacturaReporteDTO[] = [];

  async function cargarListado(): Promise<void> {
    tabla.carga();
    tabla.resumen([]);
    try {
      facturas = await servicio.obtenerFacturas(filtros);
      if (facturas.length === 0) {
        tabla.vacio();
      } else {
        tabla.render(facturas);
      }
      tabla.resumen(facturas);
    } catch (error: unknown) {
      tabla.error(mensajeDeError(error), () => void cargarListado());
      tabla.resumen([]);
    }
  }

  async function onAccion(accion: AccionFila, factura: FacturaReporteDTO): Promise<void> {
    if (accion === 'estado') {
      const nuevo = await pedirEstado(factura);
      if (!nuevo || nuevo === factura.estado) return;
      try {
        await servicio.actualizarFactura(factura.id, { estado: nuevo });
        mostrarToast('exito', `Factura ${factura.numeroFactura} actualizada a ${nuevo}.`);
        await cargarListado();
      } catch (error: unknown) {
        mostrarToast('error', mensajeDeError(error));
      }
      return;
    }
    if (accion === 'editar') {
      const cambios = await editarFactura(factura, catalogos, servicio);
      if (!cambios) return;
      try {
        await servicio.actualizarFactura(factura.id, cambios);
        mostrarToast('exito', `Factura ${factura.numeroFactura} actualizada.`);
        await cargarListado();
      } catch (error: unknown) {
        mostrarToast('error', mensajeDeError(error));
      }
      return;
    }
    const ok = await confirmar({
      titulo: 'Anular factura',
      mensaje: `Se anulará la factura N° ${factura.numeroFactura} (quedará registrada como ANULADA).`,
      textoAccion: 'Anular',
    });
    if (!ok) return;
    try {
      await servicio.anularFactura(factura.id);
      mostrarToast('exito', `Factura ${factura.numeroFactura} anulada.`);
      await cargarListado();
    } catch (error: unknown) {
      mostrarToast('error', mensajeDeError(error));
    }
  }

  const modal = initFacturaModal({
    catalogos,
    servicio,
    alGuardar: () => cargarListado(),
    sugerirNumero: () => {
      const max = facturas.reduce((m, f) => Math.max(m, f.numeroFactura), 0);
      return max + 1;
    },
  });

  qs<HTMLButtonElement>('#btn-nueva').addEventListener('click', () => modal.abrir());
  initFiltrosForm(qs<HTMLFormElement>('#form-filtros'), {
    alBuscar: (f) => {
      filtros = f;
      void cargarListado();
    },
    alLimpiar: () => {
      filtros = {};
      void cargarListado();
    },
  });

  await cargarListado();
}

function mostrarFatal(mensaje: string): void {
  const fatal = qs<HTMLElement>('#fatal');
  fatal.hidden = false;
  fatal.textContent = `No se pudo iniciar la app: ${mensaje}`;
}
