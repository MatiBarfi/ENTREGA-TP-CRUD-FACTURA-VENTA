import type { FacturaRequestDTO, FacturaReporteDTO, FacturaFiltrosDTO, FacturaUpdateDTO, FacturaResponseDTO } from '../models/factura.dto';
import { RUTAS } from '../config/api';
import { peticion } from './httpClient';

function construirQuery(filtros: FacturaFiltrosDTO): string {
  const params = new URLSearchParams();
  if (filtros.fechaDesde) params.append('fechaDesde', filtros.fechaDesde);
  if (filtros.fechaHasta) params.append('fechaHasta', filtros.fechaHasta);
  if (filtros.estado) params.append('estado', filtros.estado);
  if (filtros.montoMinimo !== undefined) params.append('montoMinimo', String(filtros.montoMinimo));
  const qs = params.toString();
  return qs ? `${RUTAS.facturas}?${qs}` : RUTAS.facturas;
}

function jsonPost(body: unknown): RequestInit {
  return { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

export class FacturaService {
  private readonly baseUrl: string = RUTAS.facturas;

  public obtenerFacturas(filtros: FacturaFiltrosDTO = {}): Promise<FacturaReporteDTO[]> {
    return peticion<FacturaReporteDTO[]>(construirQuery(filtros));
  }

  /** Detalle completo para precargar la edición. */
  public obtenerFactura(id: number): Promise<FacturaResponseDTO> {
    return peticion<FacturaResponseDTO>(`${this.baseUrl}/${id}`);
  }

  public crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
    return peticion<FacturaReporteDTO>(this.baseUrl, jsonPost(factura));
  }

  /** Anular = baja lógica vía DELETE /{id}. La factura sigue listada como ANULADA. */
  public anularFactura(id: number): Promise<void> {
    return peticion<void>(`${this.baseUrl}/${id}`, { method: 'DELETE' });
  }

  /** Actualización parcial vía PUT /{id}: solo se aplican los campos enviados. */
  public actualizarFactura(id: number, cambios: FacturaUpdateDTO): Promise<FacturaReporteDTO> {
    return peticion<FacturaReporteDTO>(`${this.baseUrl}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cambios),
    });
  }
}
