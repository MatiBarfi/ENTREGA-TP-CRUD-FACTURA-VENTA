import type {
  ArticuloDTO,
  ClienteDTO,
  CondicionIvaDTO,
  PuntoVentaDTO,
  TipoMonedaDTO,
} from '../models/catalogo.dto';
import { RUTAS } from '../config/api';
import { peticion } from './httpClient';

export type Catalogos = {
  readonly clientes: readonly ClienteDTO[];
  readonly condicionesIva: readonly CondicionIvaDTO[];
  readonly puntosVenta: readonly PuntoVentaDTO[];
  readonly tiposMoneda: readonly TipoMonedaDTO[];
  readonly articulos: readonly ArticuloDTO[];
};

/** Carga los 5 catálogos en paralelo para poblar los selects del alta. */
export async function obtenerCatalogos(): Promise<Catalogos> {
  const [clientes, condicionesIva, puntosVenta, tiposMoneda, articulos] = await Promise.all([
    peticion<ClienteDTO[]>(RUTAS.clientes),
    peticion<CondicionIvaDTO[]>(RUTAS.condicionesIva),
    peticion<PuntoVentaDTO[]>(RUTAS.puntosVenta),
    peticion<TipoMonedaDTO[]>(RUTAS.tiposMoneda),
    peticion<ArticuloDTO[]>(RUTAS.articulos),
  ]);
  return { clientes, condicionesIva, puntosVenta, tiposMoneda, articulos };
}
