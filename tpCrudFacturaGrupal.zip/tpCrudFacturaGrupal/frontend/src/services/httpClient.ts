import type { ErrorRespuestaDTO } from '../models/error.dto';

/** Error HTTP con el mensaje que devolvió el backend (si lo hubo). */
export class HttpError extends Error {
  readonly status: number;
  readonly cuerpo: string;

  constructor(status: number, cuerpo: string, message: string) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.cuerpo = cuerpo;
  }
}

function extraerMensaje(texto: string, status: number): string {
  const recortado = texto.trim();
  if (recortado.length === 0) return `El servidor respondió con error ${status}.`;
  // El backend devuelve errores amigables como {"mensaje":"..."}: mostrar ese texto.
  try {
    const json = JSON.parse(recortado) as Partial<ErrorRespuestaDTO> & { message?: unknown };
    const mensaje =
      typeof json.mensaje === 'string' && json.mensaje.trim() !== ''
        ? json.mensaje
        : typeof json.message === 'string'
          ? json.message
          : '';
    if (mensaje) return mensaje.length > 300 ? `${mensaje.slice(0, 300)}…` : mensaje;
  } catch {
    // No es JSON: se muestra el texto tal cual abajo.
  }
  if (recortado.length > 300) return `${recortado.slice(0, 300)}…`;
  return recortado;
}

/** Wrapper de fetch con manejo uniforme: nunca silencia errores. */
export async function peticion<T>(url: string, opciones?: RequestInit): Promise<T> {
  let respuesta: Response;
  try {
    respuesta = await fetch(url, opciones);
  } catch {
    throw new HttpError(0, '', 'No se pudo conectar con el backend (¿está corriendo en http://localhost:8080?).');
  }
  if (respuesta.status === 204) return undefined as T;
  const texto = await respuesta.text();
  if (!respuesta.ok) {
    throw new HttpError(respuesta.status, texto, extraerMensaje(texto, respuesta.status));
  }
  if (texto.trim().length === 0) return undefined as T;
  return JSON.parse(texto) as T;
}

/** Mensaje legible para mostrar en un toast, sea cual sea el error. */
export function mensajeDeError(error: unknown): string {
  if (error instanceof HttpError) return error.message;
  if (error instanceof Error) return error.message;
  return 'Ocurrió un error inesperado.';
}
