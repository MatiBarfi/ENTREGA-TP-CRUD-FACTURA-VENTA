import type { ArticuloDTO } from '../models/catalogo.dto';
import type { ItemBorrador, ItemsStore } from '../state/itemsStore';
import { subtotalItem } from '../state/itemsStore';
import { crearElemento, limpiarHijos } from '../utils/dom';
import { aNumero, formatearMoneda } from '../utils/formato';

/** Editor de renglones: renderiza el store y propaga cambios sin perder el foco.
 *  Recibe el tbody y el elemento de error para poder usarse en alta y edición. */
export function initEditorItems(
  body: HTMLTableSectionElement,
  errorItems: HTMLElement,
  store: ItemsStore,
  articulos: readonly ArticuloDTO[],
  alCambiar: () => void,
): { agregarFila: () => void; limpiar: () => void } {

  function articuloPorId(id: number): ArticuloDTO | undefined {
    return articulos.find((a) => a.id === id);
  }

  function selectArticulo(item: ItemBorrador): HTMLSelectElement {
    const sel = crearElemento('select');
    sel.dataset['uid'] = String(item.uid);
    sel.setAttribute('aria-label', 'Artículo del renglón');
    sel.appendChild(new Option('Seleccionar…', ''));
    for (const art of articulos) {
      const opt = new Option(`${art.codigo} · ${art.denominacion}`, String(art.id));
      if (art.id === item.articuloId) opt.selected = true;
      sel.appendChild(opt);
    }
    sel.addEventListener('change', () => {
      const art = articuloPorId(aNumero(sel.value, 0));
      store.actualizar(item.uid, {
        articuloId: art ? art.id : 0,
        descripcion: art ? art.denominacion : item.descripcion,
        precioReferencial: art ? art.precioVenta : 0,
      });
      dibujar(); // re-dibuja para autocompletar descripción y precio
      alCambiar();
    });
    return sel;
  }

  function inputNumerico(valor: number, etiqueta: string, paso: string): HTMLInputElement {
    const input = crearElemento('input', 'num');
    input.type = 'number';
    input.min = '0';
    input.step = paso;
    input.value = String(valor);
    input.setAttribute('aria-label', etiqueta);
    return input;
  }

  function fila(item: ItemBorrador): HTMLTableRowElement {
    const tr = crearElemento('tr');
    tr.dataset['uid'] = String(item.uid);

    const tdArt = crearElemento('td');
    tdArt.appendChild(selectArticulo(item));

    const tdDesc = crearElemento('td');
    const desc = crearElemento('input');
    desc.type = 'text';
    desc.value = item.descripcion;
    desc.maxLength = 255;
    desc.placeholder = 'Descripción';
    desc.setAttribute('aria-label', 'Descripción del renglón');
    desc.addEventListener('input', () => {
      store.actualizar(item.uid, { descripcion: desc.value });
      alCambiar();
    });
    tdDesc.appendChild(desc);

    const tdCant = crearElemento('td');
    const cant = inputNumerico(item.cantidad, 'Cantidad', '0.01');
    cant.min = '0';
    cant.addEventListener('input', () => {
      store.actualizar(item.uid, { cantidad: aNumero(cant.value, 0) });
      actualizarSubtotal(tr, item.uid);
      alCambiar();
    });
    tdCant.appendChild(cant);

    const tdBonif = crearElemento('td');
    const bonif = inputNumerico(item.porcentajeBonificacion, 'Porcentaje de bonificación', '0.01');
    bonif.min = '0';
    bonif.max = '100';
    bonif.addEventListener('input', () => {
      store.actualizar(item.uid, { porcentajeBonificacion: aNumero(bonif.value, 0) });
      actualizarSubtotal(tr, item.uid);
      alCambiar();
    });
    tdBonif.appendChild(bonif);

    const art = articuloPorId(item.articuloId);
    const tdPrecio = crearElemento('td', 'num ref', formatearMoneda(art ? art.precioVenta : 0));
    const tdSub = crearElemento(
      'td',
      'num subtotal',
      formatearMoneda(subtotalItem(item.cantidad, item.porcentajeBonificacion, art ? art.precioVenta : 0)),
    );

    const tdQuitar = crearElemento('td', 'acciones');
    const btn = crearElemento('button', 'btn-icono btn-quitar', 'Quitar renglón');
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Quitar renglón');
    btn.textContent = '×';
    btn.addEventListener('click', () => {
      store.quitar(item.uid);
      dibujar();
      alCambiar();
    });
    tdQuitar.appendChild(btn);

    tr.append(tdArt, tdDesc, tdCant, tdBonif, tdPrecio, tdSub, tdQuitar);
    return tr;
  }

  function actualizarSubtotal(tr: HTMLTableRowElement, uid: number): void {
    const actual = store.obtener().find((i) => i.uid === uid);
    const celdaSub = tr.querySelector('td.subtotal');
    if (actual && celdaSub) {
      celdaSub.textContent = formatearMoneda(
        subtotalItem(actual.cantidad, actual.porcentajeBonificacion, actual.precioReferencial),
      );
    }
  }

  function dibujar(): void {
    limpiarHijos(body);
    const items = store.obtener();
    if (items.length === 0) {
      const tr = crearElemento('tr', 'fila-vacia');
      const td = crearElemento('td', undefined, 'Sin renglones. Usá “Agregar ítem” para sumar el primero.');
      td.colSpan = 7;
      tr.appendChild(td);
      body.appendChild(tr);
      return;
    }
    for (const item of items) body.appendChild(fila(item));
  }

  function mostrarErrorItems(mensaje: string): void {
    errorItems.textContent = mensaje;
    errorItems.hidden = mensaje.length === 0;
  }

  store.suscribir(() => {
    mostrarErrorItems('');
  });
  dibujar();

  return {
    agregarFila(): void {
      const creado = store.agregar();
      dibujar();
      alCambiar();
      const sel = body.querySelector(`tr[data-uid="${creado.uid}"] select`);
      if (sel instanceof HTMLSelectElement) sel.focus();
    },
    limpiar(): void {
      store.limpiar();
      dibujar();
      mostrarErrorItems('');
      alCambiar();
    },
  };
}
