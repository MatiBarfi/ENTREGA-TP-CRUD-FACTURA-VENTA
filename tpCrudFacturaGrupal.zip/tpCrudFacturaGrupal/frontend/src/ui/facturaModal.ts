import type { Catalogos } from '../services/CatalogoService';
import type { FacturaService } from '../services/FacturaService';
import type { FacturaDetalleRequestDTO, FacturaRequestDTO } from '../models/factura.dto';
import { ESTADO_EMITIDA } from '../config/constantes';
import { crearItemsStore } from '../state/itemsStore';
import { fijarErrorCampo, limpiarErrores, qs } from '../utils/dom';
import { aNumero, formatearMoneda, hoyISO } from '../utils/formato';
import { validarCabecera, validarItem, type CabeceraAlta } from '../utils/validaciones';
import { mensajeDeError } from '../services/httpClient';
import { confirmar } from './confirmDialog';
import { initEditorItems } from './itemsEditor';
import { mostrarToast } from './toast';

export type ModalDeps = {
  readonly catalogos: Catalogos;
  readonly servicio: FacturaService;
  readonly alGuardar: () => Promise<void>;
  readonly sugerirNumero: () => number;
};

function poblarSelect(sel: HTMLSelectElement, opciones: readonly { id: number; texto: string }[]): void {
  sel.replaceChildren(new Option('Seleccionar…', ''));
  for (const op of opciones) sel.appendChild(new Option(op.texto, String(op.id)));
}

/** Modal de alta: formulario, renglones, totales en vivo y guardado. */
export function initFacturaModal(deps: ModalDeps): { abrir: () => void } {
  const dialogo = qs<HTMLDialogElement>('#dialogo-factura');
  const form = qs<HTMLFormElement>('#form-factura', dialogo);
  const numero = qs<HTMLInputElement>('#alta-numero');
  const fecha = qs<HTMLInputElement>('#alta-fecha');
  const cliente = qs<HTMLSelectElement>('#alta-cliente');
  const iva = qs<HTMLSelectElement>('#alta-iva');
  const puntoVenta = qs<HTMLSelectElement>('#alta-pv');
  const moneda = qs<HTMLSelectElement>('#alta-moneda');
  const cobrado = qs<HTMLInputElement>('#alta-cobrado');
  const obs = qs<HTMLInputElement>('#alta-obs');
  const btnGuardar = qs<HTMLButtonElement>('#btn-guardar');
  const btnAgregar = qs<HTMLButtonElement>('#btn-agregar-item');
  const errorItems = qs<HTMLElement>('#error-items');
  const elNeto = qs<HTMLElement>('#total-neto');
  const elIva = qs<HTMLElement>('#total-iva');
  const elTotal = qs<HTMLElement>('#total-general');
  const elSaldo = qs<HTMLElement>('#total-saldo');

  const store = crearItemsStore();
  const itemsBody = qs<HTMLTableSectionElement>('#items-body');
  const editor = initEditorItems(itemsBody, errorItems, store, deps.catalogos.articulos, actualizarTotales);
  let sucio = false;
  let guardando = false;

  poblarSelect(cliente, deps.catalogos.clientes.map((c) => ({ id: c.id, texto: `${c.denominacion} · ${c.cuitCuil}` })));
  poblarSelect(iva, deps.catalogos.condicionesIva.map((c) => ({ id: c.id, texto: c.denominacion })));
  poblarSelect(puntoVenta, deps.catalogos.puntosVenta.map((p) => ({ id: p.id, texto: p.descripcion })));
  poblarSelect(moneda, deps.catalogos.tiposMoneda.map((t) => ({ id: t.id, texto: `${t.denominacion} (${t.simbolo})` })));

  function marcarSucio(): void {
    sucio = true;
  }

  function actualizarTotales(): void {
    const t = store.totales();
    const cob = aNumero(cobrado.value, 0);
    elNeto.textContent = formatearMoneda(t.neto);
    elIva.textContent = formatearMoneda(t.iva);
    elTotal.textContent = formatearMoneda(t.total);
    elSaldo.textContent = formatearMoneda(t.total - cob);
  }

  function resetear(): void {
    form.reset();
    limpiarErrores(form);
    editor.limpiar();
    fecha.value = hoyISO();
    numero.value = String(deps.sugerirNumero());
    cobrado.value = '0';
    sucio = false;
    actualizarTotales();
  }

  function leerCabecera(): CabeceraAlta {
    return {
      numero: numero.value,
      fecha: fecha.value,
      clienteId: cliente.value,
      ivaId: iva.value,
      puntoVentaId: puntoVenta.value,
      monedaId: moneda.value,
      cobrado: cobrado.value,
    };
  }

  function validar(): FacturaRequestDTO | null {
    limpiarErrores(form);
    const cab = leerCabecera();
    const errores = validarCabecera(cab, store.totales().total);
    const items = store.obtener();
    let msgItem = '';
    if (items.length === 0) {
      msgItem = 'La factura debe tener al menos 1 ítem.';
    } else {
      for (const item of items) {
        const m = validarItem(item);
        if (m) {
          msgItem = `Renglón ${items.indexOf(item) + 1}: ${m}`;
          break;
        }
      }
    }
    errorItems.textContent = msgItem;
    errorItems.hidden = msgItem.length === 0;

    let primerId: string | null = null;
    for (const [id, msg] of Object.entries(errores)) {
      fijarErrorCampo({ id }, msg);
      if (!primerId) primerId = id;
    }
    if (primerId) {
      document.getElementById(primerId)?.focus();
      return null;
    }
    if (msgItem) {
      qs<HTMLButtonElement>('#btn-agregar-item').focus();
      return null;
    }
    const total = store.totales().total;
    const detalles: FacturaDetalleRequestDTO[] = items.map((item) => ({
      descripcion: item.descripcion.trim(),
      cantidad: item.cantidad,
      porcentajeBonificacion: item.porcentajeBonificacion,
      articuloId: item.articuloId,
    }));
    return {
      numeroFactura: Number(cab.numero),
      fechaEmision: cab.fecha,
      importeCobrado: Number(cab.cobrado),
      importeSaldo: total - Number(cab.cobrado),
      importeTotal: total,
      observaciones: obs.value.trim(),
      estado: ESTADO_EMITIDA,
      clienteId: Number(cab.clienteId),
      condicionIvaId: Number(cab.ivaId),
      puntoVentaId: Number(cab.puntoVentaId),
      tipoMonedaId: Number(cab.monedaId),
      detalles,
    };
  }

  function setGuardando(valor: boolean): void {
    guardando = valor;
    btnGuardar.disabled = valor;
    btnGuardar.querySelector('.btn-texto')!.textContent = valor ? 'Guardando…' : 'Guardar factura';
    btnGuardar.classList.toggle('cargando', valor);
  }

  async function intentarCerrar(): Promise<void> {
    if (guardando) return;
    if (sucio) {
      const salir = await confirmar({
        titulo: 'Descartar factura',
        mensaje: 'Tenés datos sin guardar. ¿Cerrar y descartarlos?',
        textoAccion: 'Descartar',
        peligrosa: true,
      });
      if (!salir) return;
    }
    dialogo.close();
  }

  form.addEventListener('input', marcarSucio);
  form.addEventListener('change', marcarSucio);
  cobrado.addEventListener('input', actualizarTotales);
  btnAgregar.addEventListener('click', () => {
    marcarSucio();
    editor.agregarFila();
  });
  qs('#btn-cancelar').addEventListener('click', () => {
    void intentarCerrar();
  });
  qs('#btn-cerrar-modal').addEventListener('click', () => {
    void intentarCerrar();
  });
  dialogo.addEventListener('click', (ev) => {
    if (ev.target === dialogo) void intentarCerrar();
  });
  dialogo.addEventListener('cancel', (ev) => {
    ev.preventDefault(); // Esc pasa por el aviso si hay datos
    void intentarCerrar();
  });

  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    if (guardando) return;
    const dto = validar();
    if (!dto) return;
    setGuardando(true);
    deps.servicio
      .crearFactura(dto)
      .then(() => {
        sucio = false;
        dialogo.close();
        resetear();
        mostrarToast('exito', `Factura ${dto.numeroFactura} guardada correctamente.`);
        return deps.alGuardar();
      })
      .catch((error: unknown) => {
        mostrarToast('error', mensajeDeError(error));
      })
      .finally(() => {
        setGuardando(false);
      });
  });

  resetear();

  return {
    abrir(): void {
      resetear();
      dialogo.showModal();
      numero.focus();
    },
  };
}
