import type { FacturaReporteDTO } from '../models/factura.dto';
import { ESTADO_EMITIDA, ESTADO_PAGADA, ESTADO_PENDIENTE } from '../config/constantes';
import { crearElemento, limpiarHijos } from '../utils/dom';

let dialogo: HTMLDialogElement | null = null;

/** Modal chico para cambiar solo el estado vía PUT /{id}. Resuelve el nuevo estado o null. */
export function pedirEstado(factura: FacturaReporteDTO): Promise<string | null> {
  if (!dialogo) {
    dialogo = crearElemento('dialog');
    dialogo.id = 'dialogo-estado';
    document.body.appendChild(dialogo);
  }
  const dlg = dialogo;
  limpiarHijos(dlg);

  return new Promise<string | null>((resolver) => {
    let resuelto = false;
    function cerrar(valor: string | null): void {
      if (resuelto) return;
      resuelto = true;
      dlg.close();
      resolver(valor);
    }

    const titulo = crearElemento('h2', 'confirm-titulo', `Estado de factura ${factura.numeroFactura}`);
    titulo.id = 'estado-titulo';
    dlg.setAttribute('aria-labelledby', 'estado-titulo');

    const campo = crearElemento('div', 'campo');
    const label = crearElemento('label', undefined, 'Nuevo estado');
    label.setAttribute('for', 'estado-select');
    const select = crearElemento('select');
    select.id = 'estado-select';
    // Sin Anulada: la anulación se hace exclusivamente con el botón Anular.
    const opciones = [ESTADO_EMITIDA, ESTADO_PENDIENTE, ESTADO_PAGADA] as const;
    for (const op of opciones) select.appendChild(new Option(op, op));
    if ((opciones as readonly string[]).includes(factura.estado)) select.value = factura.estado;
    campo.append(label, select);

    const nota = crearElemento('p', 'nota', 'Para anular usá el botón Anular de la fila.');

    const pie = crearElemento('div', 'confirm-pie');
    const btnCancelar = crearElemento('button', 'btn btn-secundario', 'Cancelar');
    btnCancelar.type = 'button';
    const btnGuardar = crearElemento('button', 'btn btn-primario', 'Guardar');
    btnGuardar.type = 'button';
    pie.append(btnCancelar, btnGuardar);
    dlg.append(titulo, campo, nota, pie);

    btnCancelar.addEventListener('click', () => cerrar(null));
    btnGuardar.addEventListener('click', () => cerrar(select.value));
    dlg.addEventListener('cancel', () => cerrar(null), { once: true });
    dlg.addEventListener('click', (ev) => {
      if (ev.target === dlg) cerrar(null);
    });

    dlg.showModal();
    select.focus();
  });
}
