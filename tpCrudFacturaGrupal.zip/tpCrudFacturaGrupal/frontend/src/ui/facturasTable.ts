import type { FacturaReporteDTO } from '../models/factura.dto';
import { ESTADO_ANULADA, ESTADO_PAGADA, ESTADO_PENDIENTE } from '../config/constantes';
import { crearElemento, limpiarHijos, qs } from '../utils/dom';
import { formatearFechaISO, formatearMoneda } from '../utils/formato';

export type AccionFila = 'estado' | 'editar' | 'anular';

export type TablaCallbacks = {
  readonly alAccionar: (accion: AccionFila, factura: FacturaReporteDTO) => void;
};

const SVG_ANULAR =
  '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true" fill="currentColor"><path d="M5.28 2.22a.75.75 0 0 0-1.06 1.06L6.94 6H2.5a.75.75 0 0 0 0 1.5h4.44l-2.72 2.72a.75.75 0 1 0 1.06 1.06L9.56 7l-4.28-4.78Z"/><path d="M9.5 2.5a.75.75 0 0 1 .75-.75h2.5c.97 0 1.75.78 1.75 1.75v9c0 .97-.78 1.75-1.75 1.75h-2.5a.75.75 0 0 1 0-1.5h2.5a.25.25 0 0 0 .25-.25v-9a.25.25 0 0 0-.25-.25h-2.5a.75.75 0 0 1-.75-.75Z"/></svg>';
const SVG_ESTADO =
  '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true" fill="currentColor"><path d="M2.5 2.75a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 .53.22l3.5 3.5a.75.75 0 0 1 0 1.06l-5.5 5.5a.75.75 0 0 1-1.06 0l-4.5-4.5a.75.75 0 0 1-.22-.53V2.75Zm1.5.75v3.69l3.72 3.72 4.44-4.44-2.97-2.97H4Z"/></svg>';
const SVG_EDITAR =
  '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true" fill="currentColor"><path d="M11.54 2.46a1.75 1.75 0 0 1 2.47 2.47l-6.7 6.7a.75.75 0 0 1-.53.22H4.5a.75.75 0 0 1-.75-.75v-2.28c0-.2.08-.39.22-.53l7.57-5.83ZM13.5 3.5a.25.25 0 0 0-.35 0L12 4.65l1.35 1.35 1.15-1.15a.25.25 0 0 0 0-.35L13.5 3.5ZM11.44 6.06 5.5 11.99v.51h.51l5.93-5.94-1.5-1.5Z"/></svg>';

const ICONOS: Record<AccionFila, string> = {
  estado: SVG_ESTADO,
  editar: SVG_EDITAR,
  anular: SVG_ANULAR,
};

function celda(texto: string, clase?: string): HTMLTableCellElement {
  return crearElemento('td', clase, texto);
}

function badgeEstado(estado: string): HTMLSpanElement {
  if (estado === ESTADO_ANULADA) return crearElemento('span', 'badge badge-anulada', 'Anulada');
  if (estado === ESTADO_PAGADA) return crearElemento('span', 'badge badge-pagada', 'Pagada');
  if (estado === ESTADO_PENDIENTE) return crearElemento('span', 'badge badge-pendiente', 'Pendiente');
  return crearElemento('span', 'badge badge-emitida', 'Emitida');
}

function botonIcono(accion: AccionFila, etiqueta: string, deshabilitado: boolean): HTMLButtonElement {
  const btn = crearElemento('button', `btn-icono btn-${accion}`);
  btn.type = 'button';
  btn.dataset['accion'] = accion;
  btn.title = etiqueta;
  btn.setAttribute('aria-label', etiqueta);
  btn.disabled = deshabilitado;
  btn.innerHTML = ICONOS[accion]; // SVG estático propio
  return btn;
}

/** Tabla con delegación de eventos: un solo listener para todas las filas. */
export function initTablaFacturas(cb: TablaCallbacks): {
  render: (facturas: readonly FacturaReporteDTO[]) => void;
  carga: () => void;
  vacio: () => void;
  error: (mensaje: string, reintentar: () => void) => void;
  resumen: (facturas: readonly FacturaReporteDTO[]) => void;
} {
  const body = qs<HTMLTableSectionElement>('#facturas-body');
  const estado = qs<HTMLElement>('#estado-listado');
  const resumen = qs<HTMLElement>('#resumen');
  let actuales: readonly FacturaReporteDTO[] = [];

  body.addEventListener('click', (ev) => {
    const btn = (ev.target as HTMLElement).closest('button[data-accion]');
    if (!btn || !(btn instanceof HTMLButtonElement) || btn.disabled) return;
    const id = Number(btn.dataset['id']);
    const factura = actuales.find((f) => f.id === id);
    if (!factura) return;
    const accion = btn.dataset['accion'];
    if (accion !== 'estado' && accion !== 'editar' && accion !== 'anular') return;
    cb.alAccionar(accion, factura);
  });

  function ocultarEstado(): void {
    estado.hidden = true;
    limpiarHijos(estado);
  }

  function fila(f: FacturaReporteDTO): HTMLTableRowElement {
    const tr = crearElemento('tr');
    const anulada = f.estado === ESTADO_ANULADA;
    if (anulada) tr.classList.add('fila-anulada');
    tr.append(
      celda(String(f.numeroFactura), 'num'),
      celda(formatearFechaISO(f.fechaEmision)),
      celda(f.clienteDenominacion),
      celda(f.condicionIva),
      celda(f.puntoVentaDescripcion),
      celda(String(f.cantidadItems), 'num'),
      celda(formatearMoneda(f.importeTotal), 'num total'),
    );
    const tdEstado = crearElemento('td');
    tdEstado.appendChild(badgeEstado(f.estado));
    const tdAcc = crearElemento('td', 'acciones');
    const btnEstado = botonIcono('estado', `Cambiar estado de factura ${f.numeroFactura}`, false);
    const btnEditar = botonIcono('editar', `Editar factura ${f.numeroFactura}`, false);
    const btnAnular = botonIcono('anular', `Anular factura ${f.numeroFactura}`, anulada);
    btnEstado.dataset['id'] = String(f.id);
    btnEditar.dataset['id'] = String(f.id);
    btnAnular.dataset['id'] = String(f.id);
    tdAcc.append(btnEstado, btnEditar, btnAnular);
    tr.append(tdEstado, tdAcc);
    return tr;
  }

  return {
    render(facturas: readonly FacturaReporteDTO[]): void {
      actuales = facturas;
      limpiarHijos(body);
      ocultarEstado();
      for (const f of facturas) body.appendChild(fila(f));
    },
    carga(): void {
      actuales = [];
      limpiarHijos(body);
      for (let i = 0; i < 5; i += 1) {
        const tr = crearElemento('tr', 'skeleton-fila');
        for (let c = 0; c < 9; c += 1) {
          const td = crearElemento('td');
          td.appendChild(crearElemento('span', 'skeleton'));
          tr.appendChild(td);
        }
        body.appendChild(tr);
      }
      ocultarEstado();
    },
    vacio(): void {
      actuales = [];
      limpiarHijos(body);
      limpiarHijos(estado);
      estado.hidden = false;
      const icono = crearElemento('p', 'vacio-icono', '🧾');
      icono.setAttribute('aria-hidden', 'true');
      estado.append(icono, crearElemento('p', undefined, 'No hay facturas que coincidan con los filtros.'));
    },
    error(mensaje: string, reintentar: () => void): void {
      actuales = [];
      limpiarHijos(body);
      limpiarHijos(estado);
      estado.hidden = false;
      const btn = crearElemento('button', 'btn btn-secundario', 'Reintentar');
      btn.type = 'button';
      btn.addEventListener('click', reintentar);
      estado.append(crearElemento('p', 'error', mensaje), btn);
    },
    resumen(facturas: readonly FacturaReporteDTO[]): void {
      const total = facturas.reduce((acc, f) => acc + f.importeTotal, 0);
      const n = facturas.length;
      const texto = n === 0 ? 'Sin comprobantes' : `${n} comprobante${n === 1 ? '' : 's'} · Total ${formatearMoneda(total)}`;
      resumen.textContent = texto;
    },
  };
}
