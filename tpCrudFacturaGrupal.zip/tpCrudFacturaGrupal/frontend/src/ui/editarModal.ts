import type { Catalogos } from '../services/CatalogoService';
import type { FacturaService } from '../services/FacturaService';
import type {
  FacturaDetalleRequestDTO,
  FacturaResponseDTO,
  FacturaReporteDTO,
  FacturaUpdateDTO,
} from '../models/factura.dto';
import { ESTADO_ANULADA, ESTADO_EMITIDA, ESTADO_PAGADA, ESTADO_PENDIENTE } from '../config/constantes';
import { crearItemsStore } from '../state/itemsStore';
import { mensajeDeError } from '../services/httpClient';
import { crearElemento, limpiarHijos } from '../utils/dom';
import { aNumero, formatearMoneda } from '../utils/formato';
import { validarItem } from '../utils/validaciones';
import { confirmar } from './confirmDialog';
import { initEditorItems } from './itemsEditor';

let dialogo: HTMLDialogElement | null = null;

/** Modal de edición (cabecera + renglones) vía PUT /{id}.
 *  Precarga el detalle del backend; los renglones se pueden agregar, quitar y
 *  modificar. Resuelve los cambios o null si se cancela. */
export function editarFactura(
  factura: FacturaReporteDTO,
  catalogos: Catalogos,
  servicio: FacturaService,
): Promise<FacturaUpdateDTO | null> {
  if (!dialogo) {
    dialogo = crearElemento('dialog');
    dialogo.id = 'dialogo-editar';
    document.body.appendChild(dialogo);
  }
  const dlg = dialogo;
  limpiarHijos(dlg);

  return new Promise<FacturaUpdateDTO | null>((resolver) => {
    let resuelto = false;
    let sucio = false;
    function cerrar(valor: FacturaUpdateDTO | null): void {
      if (resuelto) return;
      resuelto = true;
      dlg.close();
      resolver(valor);
    }
    async function intentarCerrar(): Promise<void> {
      if (resuelto) return;
      if (sucio) {
        const salir = await confirmar({
          titulo: 'Descartar cambios',
          mensaje: 'Tenés cambios sin guardar. ¿Cerrar y descartarlos?',
          textoAccion: 'Descartar',
          peligrosa: true,
        });
        if (!salir) return;
      }
      cerrar(null);
    }

    const titulo = crearElemento('h2', 'confirm-titulo', `Editar factura ${factura.numeroFactura}`);
    titulo.id = 'editar-titulo';
    dlg.setAttribute('aria-labelledby', 'editar-titulo');
    const cuerpo = crearElemento('div', 'editar-cuerpo');
    cuerpo.append(crearElemento('p', undefined, 'Cargando factura…'));
    const pieBase = crearElemento('div', 'confirm-pie');
    const btnCerrar = crearElemento('button', 'btn btn-secundario', 'Cerrar');
    btnCerrar.type = 'button';
    btnCerrar.addEventListener('click', () => void intentarCerrar());
    pieBase.appendChild(btnCerrar);
    dlg.append(titulo, cuerpo, pieBase);

    dlg.addEventListener('cancel', (ev) => {
      ev.preventDefault();
      void intentarCerrar();
    });
    dlg.addEventListener('click', (ev) => {
      if (ev.target === dlg) void intentarCerrar();
    });
    dlg.showModal();

    cargar();

    function cargar(): void {
      servicio.obtenerFactura(factura.id).then(
        (dto) => {
          if (resuelto) return;
          limpiarHijos(cuerpo);
          if (pieBase.parentElement === dlg) dlg.removeChild(pieBase);
          renderForm(dto);
        },
        (error: unknown) => {
          if (resuelto) return;
          limpiarHijos(cuerpo);
          cuerpo.append(crearElemento('p', 'error', mensajeDeError(error)));
          const btnReintentar = crearElemento('button', 'btn btn-secundario', 'Reintentar');
          btnReintentar.type = 'button';
          btnReintentar.addEventListener('click', () => {
            limpiarHijos(cuerpo);
            cuerpo.append(crearElemento('p', undefined, 'Cargando factura…'));
            cargar();
          });
          cuerpo.appendChild(btnReintentar);
        },
      );
    }

    function campoFecha(valor: string): { campo: HTMLElement; input: HTMLInputElement } {
      const c = crearElemento('div', 'campo');
      const lab = crearElemento('label', undefined, 'Fecha de emisión');
      lab.setAttribute('for', 'editar-fecha');
      const inp = crearElemento('input');
      inp.id = 'editar-fecha';
      inp.type = 'date';
      inp.value = valor.slice(0, 10);
      c.append(lab, inp);
      return { campo: c, input: inp };
    }

    function campoSelect(
      id: string,
      etiqueta: string,
      actual: number | null,
      opciones: readonly { id: number; texto: string }[],
    ): { campo: HTMLElement; select: HTMLSelectElement } {
      const c = crearElemento('div', 'campo');
      const lab = crearElemento('label', undefined, etiqueta);
      lab.setAttribute('for', id);
      const sel = crearElemento('select');
      sel.id = id;
      for (const op of opciones) sel.appendChild(new Option(op.texto, String(op.id)));
      if (actual !== null) sel.value = String(actual);
      c.append(lab, sel);
      return { campo: c, select: sel };
    }

    function renderForm(dto: FacturaResponseDTO): void {
      const store = crearItemsStore();
      for (const det of dto.detalles) {
        const item = store.agregar();
        store.actualizar(item.uid, {
          articuloId: det.articuloId,
          descripcion: det.descripcion,
          cantidad: det.cantidad,
          porcentajeBonificacion: det.porcentajeBonificacion,
          precioReferencial: det.precioVenta,
        });
      }

      const grid = crearElemento('div', 'form-grid editar-grid');

      const cEstado = crearElemento('div', 'campo');
      const lEstado = crearElemento('label', undefined, 'Estado');
      lEstado.setAttribute('for', 'editar-estado');
      const sEstado = crearElemento('select');
      sEstado.id = 'editar-estado';
      const estadosEdicion = [ESTADO_EMITIDA, ESTADO_PENDIENTE, ESTADO_PAGADA, ESTADO_ANULADA] as const;
      for (const op of estadosEdicion) {
        sEstado.appendChild(new Option(op === ESTADO_ANULADA ? 'Anulada' : op, op));
      }
      if ((estadosEdicion as readonly string[]).includes(dto.estado)) sEstado.value = dto.estado;
      cEstado.append(lEstado, sEstado);
      grid.appendChild(cEstado);

      const { campo: cFecha, input: iFecha } = campoFecha(dto.fechaEmision);
      grid.appendChild(cFecha);
      const { campo: cCli, select: sCli } = campoSelect(
        'editar-cliente',
        'Cliente',
        dto.clienteId,
        catalogos.clientes.map((c) => ({ id: c.id, texto: `${c.denominacion} · ${c.cuitCuil}` })),
      );
      const { campo: cIva, select: sIva } = campoSelect(
        'editar-iva',
        'Condición IVA',
        dto.condicionIvaId,
        catalogos.condicionesIva.map((c) => ({ id: c.id, texto: c.denominacion })),
      );
      const { campo: cPv, select: sPv } = campoSelect(
        'editar-pv',
        'Punto de venta',
        dto.puntoVentaId,
        catalogos.puntosVenta.map((p) => ({ id: p.id, texto: p.descripcion })),
      );
      const { campo: cMon, select: sMon } = campoSelect(
        'editar-moneda',
        'Tipo de moneda',
        dto.tipoMonedaId,
        catalogos.tiposMoneda.map((t) => ({ id: t.id, texto: `${t.denominacion} (${t.simbolo})` })),
      );
      grid.append(cCli, cIva, cPv, cMon);

      const cCob = crearElemento('div', 'campo');
      const lCob = crearElemento('label', undefined, 'Importe cobrado');
      lCob.setAttribute('for', 'editar-cobrado');
      const iCob = crearElemento('input');
      iCob.id = 'editar-cobrado';
      iCob.type = 'number';
      iCob.min = '0';
      iCob.step = '0.01';
      iCob.value = String(dto.importeCobrado);
      cCob.append(lCob, iCob);
      grid.appendChild(cCob);

      const cObs = crearElemento('div', 'campo campo-ancho');
      const lObs = crearElemento('label', undefined, 'Observaciones');
      lObs.setAttribute('for', 'editar-obs');
      const iObs = crearElemento('input');
      iObs.id = 'editar-obs';
      iObs.type = 'text';
      iObs.maxLength = 255;
      iObs.value = dto.observaciones ?? '';
      cObs.append(lObs, iObs);
      grid.appendChild(cObs);

      const fieldset = crearElemento('fieldset');
      fieldset.appendChild(crearElemento('legend', undefined, 'Renglones'));
      const btnAgregar = crearElemento('button', 'btn btn-secundario', 'Agregar ítem');
      btnAgregar.type = 'button';
      const errItems = crearElemento('p', 'error', '');
      errItems.hidden = true;
      const scroll = crearElemento('div', 'tabla-scroll');
      const tabla = crearElemento('table');
      const thead = crearElemento('thead');
      const trHead = crearElemento('tr');
      for (const h of ['Artículo', 'Descripción', 'Cant.', 'Bonif. %', 'Precio ref.', 'Subtotal', '']) {
        trHead.appendChild(crearElemento('th', undefined, h));
      }
      thead.appendChild(trHead);
      const tbody = crearElemento('tbody');
      tbody.id = 'editar-items-body';
      tabla.append(thead, tbody);
      scroll.appendChild(tabla);
      fieldset.append(btnAgregar, errItems, scroll);

      const totalLinea = crearElemento('p', 'resumen', '');
      const error = crearElemento('p', 'error', '');
      error.hidden = true;

      const pie = crearElemento('div', 'confirm-pie');
      const btnCancelar = crearElemento('button', 'btn btn-secundario', 'Cancelar');
      btnCancelar.type = 'button';
      const btnGuardar = crearElemento('button', 'btn btn-primario', 'Guardar cambios');
      btnGuardar.type = 'button';
      pie.append(btnCancelar, btnGuardar);
      cuerpo.append(grid, fieldset, totalLinea, error, pie);

      function actualizarTotal(): void {
        totalLinea.textContent = `Total estimado: ${formatearMoneda(store.totales().total)}`;
      }
      const editor = initEditorItems(tbody, errItems, store, catalogos.articulos, actualizarTotal);
      actualizarTotal();

      function marcarSucio(): void {
        sucio = true;
      }
      cuerpo.addEventListener('input', marcarSucio);
      cuerpo.addEventListener('change', marcarSucio);
      btnAgregar.addEventListener('click', () => {
        marcarSucio();
        editor.agregarFila();
      });
      btnCancelar.addEventListener('click', () => void intentarCerrar());

      function mostrarError(msg: string, foco?: HTMLElement): void {
        error.textContent = msg;
        error.hidden = false;
        foco?.focus();
      }

      btnGuardar.addEventListener('click', () => {
        error.hidden = true;
        const items = store.obtener();
        if (items.length === 0) {
          mostrarError('La factura debe tener al menos 1 ítem.', btnAgregar);
          return;
        }
        for (const item of items) {
          const m = validarItem(item);
          if (m) {
            mostrarError(`Renglón ${items.indexOf(item) + 1}: ${m}`, btnAgregar);
            return;
          }
        }
        const total = store.totales().total;
        const cobrado = aNumero(iCob.value, 0);
        if (!(cobrado >= 0)) {
          mostrarError('El importe cobrado debe ser un número ≥ 0.', iCob);
          return;
        }
        if (cobrado > total) {
          mostrarError('El importe cobrado no puede superar el total.', iCob);
          return;
        }
        const detalles: FacturaDetalleRequestDTO[] = items.map((item) => ({
          descripcion: item.descripcion.trim(),
          cantidad: item.cantidad,
          porcentajeBonificacion: item.porcentajeBonificacion,
          articuloId: item.articuloId,
        }));
        const cambios: FacturaUpdateDTO = {
          estado: sEstado.value,
          observaciones: iObs.value.trim(),
          importeCobrado: cobrado,
          condicionIvaId: Number(sIva.value),
          puntoVentaId: Number(sPv.value),
          tipoMonedaId: Number(sMon.value),
          detalles,
        };
        // clienteId solo si hay una opción válida (la factura puede no tener cliente).
        if (sCli.value) cambios.clienteId = Number(sCli.value);
        if (iFecha.value) cambios.fechaEmision = iFecha.value;
        cerrar(cambios);
      });
    }
  });
}
