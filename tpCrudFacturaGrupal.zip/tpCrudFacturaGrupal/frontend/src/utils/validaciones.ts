import type { FacturaFiltrosDTO } from '../models/factura.dto';
import type { ItemEnMemoria } from '../models/factura.dto';

/** Mapa campo → mensaje. Vacío = válido. */
export type Errores = Record<string, string>;

export function validarRangoFechas(desde: string, hasta: string): string {
  if (desde && hasta && desde > hasta) {
    return 'La fecha desde no puede ser posterior a la fecha hasta.';
  }
  return '';
}

export function filtrosValidos(desde: string, hasta: string, monto: string): boolean {
  if (validarRangoFechas(desde, hasta)) return false;
  if (monto.trim() !== '' && !(Number(monto) >= 0)) return false;
  return true;
}

export function construirFiltros(desde: string, hasta: string, estado: string, monto: string): FacturaFiltrosDTO {
  const filtros: FacturaFiltrosDTO = {};
  if (desde) filtros.fechaDesde = desde;
  if (hasta) filtros.fechaHasta = hasta;
  if (estado) filtros.estado = estado;
  if (monto.trim() !== '') filtros.montoMinimo = Number(monto);
  return filtros;
}

export type CabeceraAlta = {
  numero: string;
  fecha: string;
  clienteId: string;
  ivaId: string;
  puntoVentaId: string;
  monedaId: string;
  cobrado: string;
};

/** Valida la cabecera; devuelve errores por id de campo. */
export function validarCabecera(c: CabeceraAlta, totalEstimado: number): Errores {
  const errores: Errores = {};
  if (!c.numero || !(Number(c.numero) >= 1)) errores['alta-numero'] = 'Ingresá un número de factura válido (≥ 1).';
  if (!c.fecha) errores['alta-fecha'] = 'Elegí la fecha de emisión.';
  if (!c.clienteId) errores['alta-cliente'] = 'Seleccioná un cliente.';
  if (!c.ivaId) errores['alta-iva'] = 'Seleccioná la condición de IVA.';
  if (!c.puntoVentaId) errores['alta-pv'] = 'Seleccioná el punto de venta.';
  if (!c.monedaId) errores['alta-moneda'] = 'Seleccioná el tipo de moneda.';
  const cobrado = Number(c.cobrado);
  if (c.cobrado.trim() === '' || !Number.isFinite(cobrado) || cobrado < 0) {
    errores['alta-cobrado'] = 'El importe cobrado debe ser un número ≥ 0.';
  } else if (cobrado > totalEstimado) {
    errores['alta-cobrado'] = 'El importe cobrado no puede superar el total.';
  }
  return errores;
}

/** Valida un renglón; devuelve el primer mensaje o '' si está OK. */
export function validarItem(item: ItemEnMemoria): string {
  if (!item.articuloId) return 'Elegí un artículo.';
  if (item.descripcion.trim().length === 0) return 'La descripción no puede estar vacía.';
  if (!(item.cantidad > 0)) return 'La cantidad debe ser mayor a 0.';
  if (!(item.porcentajeBonificacion >= 0 && item.porcentajeBonificacion <= 100)) {
    return 'La bonificación debe estar entre 0 y 100.';
  }
  if (!(item.precioReferencial > 0)) return 'El artículo no tiene precio de referencia.';
  return '';
}
