const monedaAR = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' });

export function formatearMoneda(valor: number): string {
  if (!Number.isFinite(valor)) return monedaAR.format(0);
  return monedaAR.format(valor);
}

/** '2026-10-12' o '2026-10-12T00:00:00...' → '12/10/2026'.
 *  Se parsea el string (no new Date) para evitar corrimientos por zona horaria. */
export function formatearFechaISO(iso: string): string {
  const fecha = iso.slice(0, 10);
  const partes = fecha.split('-');
  if (partes.length !== 3) return iso;
  const [anio, mes, dia] = partes as [string, string, string];
  return `${dia}/${mes}/${anio}`;
}

/** Hoy en zona local como yyyy-MM-dd para <input type="date">. */
export function hoyISO(): string {
  const ahora = new Date();
  const mes = String(ahora.getMonth() + 1).padStart(2, '0');
  const dia = String(ahora.getDate()).padStart(2, '0');
  return `${ahora.getFullYear()}-${mes}-${dia}`;
}

export function aNumero(valor: string, defecto = 0): number {
  if (valor.trim() === '') return defecto;
  const n = Number(valor);
  return Number.isFinite(n) ? n : defecto;
}
