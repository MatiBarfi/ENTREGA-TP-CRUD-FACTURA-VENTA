import type { ItemEnMemoria } from '../models/factura.dto';
import { IVA_PORCENTAJE } from '../config/constantes';

/** Ítem con identidad de fila para el editor (el backend no lo conoce). */
export type ItemBorrador = ItemEnMemoria & { readonly uid: number };

export type TotalesItems = {
  readonly neto: number;
  readonly iva: number;
  readonly total: number;
};

export function subtotalItem(cantidad: number, bonificacion: number, precio: number): number {
  const neto = precio * cantidad * (1 - bonificacion / 100);
  return neto * (1 + IVA_PORCENTAJE);
}

export function netoItem(cantidad: number, bonificacion: number, precio: number): number {
  return precio * cantidad * (1 - bonificacion / 100);
}

/** Suma neto/IVA/total de los ítems. Función pura: fácil de testear. */
export function calcularTotales(items: readonly ItemEnMemoria[]): TotalesItems {
  let neto = 0;
  for (const item of items) {
    neto += netoItem(item.cantidad, item.porcentajeBonificacion, item.precioReferencial);
  }
  const iva = neto * IVA_PORCENTAJE;
  return { neto, iva, total: neto + iva };
}

type Oyente = () => void;

/** Estado en memoria de los renglones: la UI se re-renderiza a partir de él. */
export function crearItemsStore(): ItemsStore {
  let items: ItemBorrador[] = [];
  let siguienteUid = 1;
  const oyentes = new Set<Oyente>();

  function notificar(): void {
    oyentes.forEach((oyente) => {
      oyente();
    });
  }

  return {
    suscribir(oyente: Oyente): () => void {
      oyentes.add(oyente);
      return () => {
        oyentes.delete(oyente);
      };
    },
    obtener(): readonly ItemBorrador[] {
      return items;
    },
    agregar(): ItemBorrador {
      const creado: ItemBorrador = {
        uid: siguienteUid,
        descripcion: '',
        cantidad: 1,
        porcentajeBonificacion: 0,
        articuloId: 0,
        precioReferencial: 0,
      };
      siguienteUid += 1;
      items = [...items, creado];
      notificar();
      return creado;
    },
    quitar(uid: number): void {
      items = items.filter((item) => item.uid !== uid);
      notificar();
    },
    actualizar(uid: number, cambios: Partial<ItemEnMemoria>): void {
      items = items.map((item) => (item.uid === uid ? { ...item, ...cambios } : item));
      notificar();
    },
    limpiar(): void {
      items = [];
      notificar();
    },
    totales(): TotalesItems {
      return calcularTotales(items);
    },
  };
}

export type ItemsStore = {
  readonly suscribir: (oyente: Oyente) => () => void;
  readonly obtener: () => readonly ItemBorrador[];
  readonly agregar: () => ItemBorrador;
  readonly quitar: (uid: number) => void;
  readonly actualizar: (uid: number, cambios: Partial<ItemEnMemoria>) => void;
  readonly limpiar: () => void;
  readonly totales: () => TotalesItems;
};
