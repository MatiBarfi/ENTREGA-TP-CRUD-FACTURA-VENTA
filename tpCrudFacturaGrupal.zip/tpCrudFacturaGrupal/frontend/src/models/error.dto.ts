/** Cuerpo de error uniforme del backend (ApiExceptionHandler.ErrorRespuesta). */
export type ErrorRespuestaDTO = {
    readonly mensaje: string;
};
