export type ClienteDTO = {
  readonly id: number;
  readonly denominacion: string;
  readonly cuitCuil: string;
};

export type CondicionIvaDTO = {
  readonly id: number;
  readonly denominacion: string;
};

export type PuntoVentaDTO = {
  readonly id: number;
  readonly descripcion: string;
};

export type TipoMonedaDTO = {
  readonly id: number;
  readonly denominacion: string;
  readonly simbolo: string;
};

export type ArticuloDTO = {
  readonly id: number;
  readonly codigo: string;
  readonly denominacion: string;
  readonly precioVenta: number;
};
