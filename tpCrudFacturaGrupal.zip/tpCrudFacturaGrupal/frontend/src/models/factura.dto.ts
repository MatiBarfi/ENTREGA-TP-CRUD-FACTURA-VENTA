export type FacturaDetalleRequestDTO = {
    descripcion: string;
    cantidad: number;
    porcentajeBonificacion: number;
    articuloId: number;
};

/** Ítem en memoria del formulario de alta. `precioReferencial` es solo informativo:
 *  el backend recalcula el precio desde ListaPrecioArticulo por articuloId. */
export type ItemEnMemoria = FacturaDetalleRequestDTO & {
    precioReferencial: number;
};

export type FacturaRequestDTO = {
    numeroFactura: number;
    /** ISO yyyy-MM-dd (el backend lo tipa como LocalDate). */
    fechaEmision: string;
    importeCobrado: number;
    importeSaldo: number;
    importeTotal: number;
    observaciones: string;
    estado: string;
    clienteId: number;
    condicionIvaId: number;
    puntoVentaId: number;
    tipoMonedaId: number;
    detalles: FacturaDetalleRequestDTO[];
};

export type FacturaReporteDTO = {
    id: number;
    numeroFactura: number;
    fechaEmision: string;
    importeTotal: number;
    clienteDenominacion: string;
    condicionIva: string;
    puntoVentaDescripcion: string;
    cantidadItems: number;
    estado: string;
};

export interface FacturaFiltrosDTO {
    fechaDesde?: string;
    fechaHasta?: string;
    estado?: string;
    montoMinimo?: number;
}

/** Actualización parcial vía PUT /api/facturas/{id}: solo se envían los campos a cambiar.
 *  Si se envía `detalles`, reemplaza todos los renglones (el backend los recalcula).
 *  Espejo de FacturaUpdateDTO del backend: todos los campos son opcionales. */
export type FacturaUpdateDTO = {
    estado?: string;
    fechaEmision?: string;
    observaciones?: string;
    importeCobrado?: number;
    clienteId?: number;
    condicionIvaId?: number;
    puntoVentaId?: number;
    tipoMonedaId?: number;
    detalles?: FacturaDetalleRequestDTO[];
};

/** Renglón leído del backend (GET /api/facturas/{id}). */
export type FacturaDetalleDTO = {
    articuloId: number;
    descripcion: string;
    cantidad: number;
    porcentajeBonificacion: number;
    precioVenta: number;
};

/** Factura completa para precargar la edición. */
export type FacturaResponseDTO = {
    id: number;
    numeroFactura: number;
    estado: string;
    fechaEmision: string;
    observaciones: string;
    importeCobrado: number;
    importeTotal: number;
    importeSaldo: number;
    clienteId: number | null;
    condicionIvaId: number;
    puntoVentaId: number;
    tipoMonedaId: number;
    detalles: FacturaDetalleDTO[];
};
